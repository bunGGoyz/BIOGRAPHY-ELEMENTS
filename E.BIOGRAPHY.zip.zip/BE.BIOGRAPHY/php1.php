<?php 

$info = array ("name" => "John Emer Guillen", "Age" => "25" ,  "Sex" => "Male" , "dob" => "January 17, 1997", "nationality" => "Filipino") ;


?>
